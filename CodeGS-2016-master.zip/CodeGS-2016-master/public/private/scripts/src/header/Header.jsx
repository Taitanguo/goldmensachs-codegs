import React from 'react';
import {Button} from 'react-bootstrap';

export default class Header extends React.Component {

	/**
	 * Create component HTML
	 * @return {[type]} [description]
	 */
  	render() {
	    return (
	    	<div className="header">
	    		<span>Sandbox</span>
	    	</div>
	    );
  	}
}